Multiple File Program
-------------------

Multiple file program means each program is constructed by one or more source code files.
Each program will be using an individual folder.
Each program (or project) has its own .vscode folder.

The program exe file will be based on the folder name.

1. To get started working with this mode (i.e. multi-file program), you want to open the program folder into MS VS Code.
2. To run the program, choose the Debug settings: "multi-file console program" (for console project) or "Multi-file winbgim project" (for graphic program)
