#include <stdio.h>
#include <string.h>
#include "input.h"

void readString(const char *prompt, char *buffer, int size)
{
    printf("%s => ", prompt);
    fgets(buffer, size, stdin);
    buffer[strlen(buffer) - 1] = '\0';
}
