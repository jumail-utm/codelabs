#ifndef INPUT_H
#define INPUT_H
void readString(const char *, char *, int);
#endif