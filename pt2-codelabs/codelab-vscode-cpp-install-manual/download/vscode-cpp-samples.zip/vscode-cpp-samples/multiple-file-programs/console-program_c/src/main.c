#include <stdio.h>
#include <string.h>
#include "input/input.h"


int main()
{
	char name[40];
	readString("What is your name?", name,sizeof(name));

	printf("\n Hi %s! Welcome to the world of C programming.\n", name);
	getchar();
	return 0;
}
