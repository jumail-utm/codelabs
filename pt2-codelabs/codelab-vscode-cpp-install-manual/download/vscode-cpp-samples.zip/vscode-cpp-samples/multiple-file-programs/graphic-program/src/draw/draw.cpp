#include <graphics.h>

void drawCircle(int x, int y, int radius, int color, int fillStyle)
{
    setcolor(color);
    setfillstyle(fillStyle, color);
    fillellipse(x, y, radius, radius);
}

void drawRectangle(int x, int y, int width, int height, int color, int fillStyle)
{
    setcolor(color);
    setfillstyle(fillStyle, color);
    bar(x,y,x+width, y+height);
}
