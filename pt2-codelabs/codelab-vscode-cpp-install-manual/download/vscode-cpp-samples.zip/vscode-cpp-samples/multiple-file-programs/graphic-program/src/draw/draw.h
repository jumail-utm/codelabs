#pragma once

#include<graphics.h>

void drawCircle(int, int, int, int, int = SOLID_FILL);
void drawRectangle(int, int, int, int, int, int = SOLID_FILL);