#include <graphics.h>
#include "random/random.h"
#include "draw/draw.h"

int main()
{
    int screenWidth = getmaxwidth();
    int screenHeight = getmaxheight();
    int x, y, color;
    int type;

    initRandom();
    initwindow(screenWidth, screenHeight, "An example of graphical program using WinBGIm library");
    
    while (!kbhit())
    {
        x = randomBetween(0,screenWidth);
        y = randomBetween(0,screenHeight);
        color = COLOR(randomBetween(0,255), randomBetween(255), randomBetween(255));
        type = randomBetween(0,1); // 0: circle, 1: rectangle

        if (type == 0)
        {
            int radius = randomBetween(50, screenHeight / 4);
            drawCircle(x, y, radius, color);
        }
        else
        {
            int width = randomBetween(50, screenWidth / 4);
            int height = randomBetween(50, screenHeight / 4);
            drawRectangle(x, y, width, height,color);
        }

        delay(100);
    }

    getch();

    return 0;
}
