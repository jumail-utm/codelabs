#include <cstdlib>
#include <ctime>

void initRandom() { srand(time(NULL)); }
int randomBetween(int min, int max) { return min + rand() % (max - min + 1); }