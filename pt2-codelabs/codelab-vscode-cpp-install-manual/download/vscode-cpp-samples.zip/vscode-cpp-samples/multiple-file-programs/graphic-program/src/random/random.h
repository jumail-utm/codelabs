#pragma once

void initRandom();
int randomBetween(int=0, int=1);