Multiple File Program
---------------------

Multiple file program means each program is constructed by one or more source code files.
Each program will be using an individual folder.
Each program (or project) has its own .vscode folder.

The program exe file will be based on the folder name.

1. To get started working with this mode (i.e. multi-file program), you want to open the program folder into MS VS Code.
2. To run the program, choose the Debug settings: "multi-file console program" (for console project) or "Multi-file graphic project" (for BGI graphic program)

Sample programs:
----------------
1. [console-program] is an example console program, i.e., non-graphic or text-based program
2. [graphic-program] is an example graphic program using legacy WinBGIm graphic library

3. [bgi-graphic-program] is similar to the above [graphic-program]. The only difference is that the files need to be organized into
   certain folder structures:
    - bin (the compiled exe file will go here)
    - src (you must put your .cpp in this sub-folder)
    - include (your own header files .hpp should go into this sub-foloder)
    - res (is an optional sub-folder to put your resources files such as images, sounds, etc)

4. [sdl-graphic-program] is an example graphic program using SDL2 graphic library. You should organize your files as similar to the above program (3).
   If you copy this project to create a new one, you must ensure that you copy as well all the *.dll files under the bin sub-folder.
