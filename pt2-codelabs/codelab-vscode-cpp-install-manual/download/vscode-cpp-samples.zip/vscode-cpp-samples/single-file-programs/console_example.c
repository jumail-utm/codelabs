//----------------------------------------------------------------------------------------------------
// An example of console program (in C)
//----------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------
// Notes on working with VSCode
//   You don't want to open any .c file directly in VSCode.
//   Instead, you want to open a folder first. Then open your .c file.
//   VSCode works mostly based on (what so called "workspace").
//   Which in this case, you need to work inside a folder.
//
//   So, for this program (console_example.c), in order to run it,
//     1). open the folder named "c:\vscode-cpp-samples\single-file-programs" into VSCode
//     2). open this program file (i.e. console_example.c) into VSCode
//     3). In debug mode choose "Console program (C)"
//     4). Start debugging or running by pressing F5
//
// If you want to use your own folder, copy the folder ".vscode" from "vscode-cpp-samples\single-file-programs"
// and put it inside your own folder.
//
//----------------------------------------------------------------------------------------------------

#include <stdio.h>
#include <string.h>

int main()
{
	char name[40];

	printf("What is your name? => ");
	fgets(name, 40, stdin);
	name[strlen(name) - 1] = '\0';
	printf("\nHi %s!\n", name);
	printf("Welcome to the world of C programming.");

	getchar();
	return 0;
}
