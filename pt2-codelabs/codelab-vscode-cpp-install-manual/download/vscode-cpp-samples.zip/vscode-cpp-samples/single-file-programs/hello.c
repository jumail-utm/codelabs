#include<stdio.h>
int main()
{   int i=0;
    printf("Hello World. Greeting from C\n");
    i++;
    getchar();
    return 0;
}